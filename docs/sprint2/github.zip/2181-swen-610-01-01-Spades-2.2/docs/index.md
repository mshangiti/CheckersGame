# WebCheckers Game Home

Welcome to the WebCheckers Game Project!

## Team

* José Reyes Arias (jer4921@rit.edu)
* Moayad Alshangiti (mma4247@rit.edu)
* Harsha Vardhan Muppuri (hm9247@rit.edu)
* Murtaza Tamjeed (mt1256@rit.edu)
* Kale, Arpita (ak2071@rit.edu)

## [Design Documentation](./DesignDoc.md)

Click above for details of the WebCheckers Game design documentation.

## [Setup Guide](./SetupGuide.md)

Click above for details about how to setup your development environment to work on this project.
