# WebCheckers Setup Guide
To be completed.