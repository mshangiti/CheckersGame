package com.webcheckers.model;


/*
 * This class represents a challene
 */
public class Challenge {

    /*
    class attributes
     */
    private String challenger;
    private String opponent;
    private boolean isAccepted;

    public Challenge(String challenger, String opponent){
        this.challenger = challenger;
        this.opponent = opponent;
        this.isAccepted = false;
    }

    public String getChallengerName(){
        return this.challenger;
    }

    public String getOpponentName(){
        return this.opponent;
    }

    public void setChallengeAsAccepted(){
        this.isAccepted = true;
    }

    public boolean isChallengeAccepted(){
        if(this.isAccepted){
            return true;
        }
        //else
        return false;
    }
}

