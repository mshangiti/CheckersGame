package com.webcheckers.appl;
import java.util.ArrayList;
import java.util.Objects;
import java.util.logging.Logger;
import com.webcheckers.model.Challenge;
import spark.Session;
import com.webcheckers.model.Player;


/**
 * The object to coordinate the state of the Web Application.
 */

public class GameCenter {

    //globals
    public static final String SESSION_USER = "username";


    //list of online/active users
    private ArrayList<Player> onlinePlayers = new ArrayList<>();
    private ArrayList<Challenge> challenges = new ArrayList<>();


    /**
     * Adding a new player (at sign-in)
     *
     * @param player, Session
     *    The player to add
     *    The current session
     */

    public synchronized void addPlayer(Player player, final Session session){
        //add user to activeUsers
        onlinePlayers.add(player);

        //add to session
        session.attribute(SESSION_USER, player);
    }

    /**
     * Removing a player (at sign-out)
     *
     * @param session
     *    The current session
     */
    public synchronized void removePlayer(final Session session){

        //get user
        Player player = session.attribute(SESSION_USER);

        //remove player from any active challenges
        cancelChallenge(session);

        //add user to activeUsers
        onlinePlayers.remove(player);

        //remove from session
        session.removeAttribute(SESSION_USER);
    }

    /**
     * Removing a challenge
     *
     * @param session
     *    The current session
     */
    public synchronized void cancelChallenge(final Session session){
        //get user
        Player player = session.attribute(SESSION_USER);

        //remove player from any active challenges
        for (Challenge ch:challenges) {
            if (ch.getOpponentName().equalsIgnoreCase(player.getName()) || ch.getChallengerName().equalsIgnoreCase(player.getName())) {
                challenges.remove(ch);
                break;
            }
        }
    }

    /**
     * Check if username is in use
     *
     * @param playername
     *    The username to check
     */
    public boolean checkPlayerName(String playername){
        for (Player temp:onlinePlayers){
            if(temp.getName().equalsIgnoreCase(playername)){
                return false;
            }
        }
        return true;
    }

    /**
     * get the playername from the session
     *
     * @param session
     *    The user's session
     */
    public String getPlayerName(Session session){
        Player player = session.attribute(SESSION_USER);
        return player.getName();
    }


    /**
     * Check if player is loggedin
     *
     * @param session
     *    The user's session
     */
    public boolean checkIfLoggedIn(Session session){
        Player player = session.attribute(SESSION_USER);
        if(player != null){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * get the list of online players
     */

    public synchronized ArrayList<Player> getOnlinePlayers(){
        ArrayList<Player> availablePlayers = new ArrayList<>();
        for(Player player:onlinePlayers){
            if(playerHasActiveChallenge(player) == false){
                //if player is not part of any active challenge, then show him as available player
                availablePlayers.add(player);
            }
        }
        return availablePlayers;
    }

    /**
     * Checks if this player can challenge another player or be challenged (only 1 challenge at a time is allowed)
     *
     * @param player
     *    The player to check
     */
    public synchronized  boolean playerHasActiveChallenge(Player player){
//        Player player = session.attribute(SESSION_USER);
        for (Challenge ch:challenges){
            if(ch.getChallengerName().equalsIgnoreCase(player.getName())){
                return true;
            }
            if(ch.getOpponentName().equalsIgnoreCase(player.getName())){
                return true;
            }
        }
        //no match
        return false;
    }


    /**
     * Check if a player is being challenged
     *
     * @param session
     *    The user's session
     */
    public synchronized  boolean isPlayerBeingChallenged(Session session){
        Player player = session.attribute(SESSION_USER);
        for (Challenge ch:challenges){
            if(ch.getOpponentName().equalsIgnoreCase(player.getName())){
                return true;
            }
        }
        //if no match found
        return false;
    }

    /**
     * Creates a new challenge
     *
     * @param session, opponent
     *    The user's session
     *    The opponent's name
     */
    public synchronized  boolean challengePlayer(Session session, String opponent){
        Player player = session.attribute(SESSION_USER);
        if(playerHasActiveChallenge(new Player(opponent))){
            return false;
        }
        Challenge ch = new Challenge(player.getName(),opponent);
        challenges.add(ch);
        return true;
    }

    /**
     * Accepts a new challenge and triggers loading the game
     *
     * @param session
     *    The user's session
     */
    public synchronized  boolean acceptChallenge(Session session){
        Player player = session.attribute(SESSION_USER);
        for (Challenge ch:challenges){
            if(ch.getOpponentName().equalsIgnoreCase(player.getName())){
                ch.setChallengeAsAccepted();
                return true;
            }
        }
        return false;
    }

    /**
     * checks on the challenge status
     *
     * @param session
     *    The user's session
     */
    public synchronized  boolean isChallengeAccepted(Session session){
        Player player = session.attribute(SESSION_USER);
        for (Challenge ch:challenges){
            if(ch.getChallengerName().equalsIgnoreCase(player.getName()) || ch.getOpponentName().equalsIgnoreCase(player.getName())){
                return ch.isChallengeAccepted();
            }
        }
        return false;
    }

    /**
     * get challenger name
     *
     * @param session
     *    The user's session
     */
    public String getChallengerName(Session session) {
        Player player = session.attribute(SESSION_USER);
        for (Challenge ch : challenges) {
            if (ch.getOpponentName().equalsIgnoreCase(player.getName())) {
                return ch.getChallengerName();
            }
        }
        return "";
    }

}
