package com.webcheckers.ui;

import com.webcheckers.appl.GameCenter;
import spark.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * The {@code GET /singin} route handler.
 */

public class GetSignInRoute implements TemplateViewRoute {

    //
    // constants
    //
    static final String VIEW_NAME = "signin.ftl";
    static final String TITLE = "Welcome";
    static final String TITLE_ATTR = "title";

    //
    // Attributes
    //
    private final GameCenter gameCenter;

    //
    // Constructor
    //

    GetSignInRoute (final GameCenter gameCenter)
    {
        Objects.requireNonNull(gameCenter, "gameCenter must not be null");
        this.gameCenter = gameCenter;
    }

    //
    // TemplateViewRoute method
    //

    /**
     * {@inheritDoc}
     */
    @Override
    public ModelAndView handle(Request request, Response response) {
        // start building the View-Model
        final Map<String, Object> vm = new HashMap<>();
        vm.put(TITLE_ATTR, GetSignInRoute.TITLE);
        if(gameCenter.checkIfLoggedIn(request.session())) {
            //user logged in
            vm.put(gameCenter.SESSION_USER, gameCenter.getPlayerName(request.session()));
            return new ModelAndView(vm, HomeController.VIEW_NAME);
        }else {
            //new player
            return new ModelAndView(vm, VIEW_NAME);
        }
    }

}
