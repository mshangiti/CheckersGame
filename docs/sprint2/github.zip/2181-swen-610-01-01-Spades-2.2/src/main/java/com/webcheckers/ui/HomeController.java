package com.webcheckers.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.webcheckers.appl.GameCenter;
import com.webcheckers.model.Player;
import spark.*;

/**
 * The Web Controller for the Home page.
 *
 *
 */
public class HomeController implements TemplateViewRoute {

  //
  // Constants
  //
  static final String VIEW_NAME = "home.ftl";
  static final String TITLE = "Welcome";
  static final String PLAYER_LIST_ATTR = "playersList";
  static final String PLAYER_COUNT_ATTR = "playersCount";
  static final String IS_CHALLENGED_ATTR = "playerIsChallenged";
  static final String CHALLENGE_MSG = "challengeMessage";
  static final String USER_DECISION = "userDecision";
  static final String NEW_CHALLENGE = "opponentName";
  static final String USER_WITHDRAW = "userWithdraw";

  //
  // Attributes
  //
  private final GameCenter gameCenter;

  //
  // Constructor
  //

    HomeController (final GameCenter gameCenter)
    {
        Objects.requireNonNull(gameCenter, "gameCenter must not be null");
        this.gameCenter = gameCenter;
    }

  @Override
  public ModelAndView handle(Request request, Response response) {
    Map<String, Object> vm = new HashMap<>();
    vm.put("title", HomeController.TITLE);
    
    if(gameCenter.checkIfLoggedIn(request.session())) {
        //user loggedin
        ArrayList<Player> onlinePlayers = gameCenter.getOnlinePlayers();
        vm.put(PLAYER_LIST_ATTR, onlinePlayers);
        vm.put(PLAYER_COUNT_ATTR, onlinePlayers.size()-1);
        vm.put(gameCenter.SESSION_USER, gameCenter.getPlayerName(request.session()));

        //check if a player has been challenged, or already has challenged someone
        if(gameCenter.playerHasActiveChallenge(request.session().attribute(gameCenter.SESSION_USER))){
          //player is part of a challenge, now check if he's being challenged
          if(gameCenter.isPlayerBeingChallenged(request.session())){
            //player is being challenged, check if decision was made
            final String userDecision = request.queryParams(USER_DECISION);
            if(userDecision != null){
              if(userDecision.equalsIgnoreCase("Accept")){
                //yes, update status
                gameCenter.acceptChallenge(request.session());
                vm = loadGame(vm);
              }else if(userDecision.equalsIgnoreCase("Decline")){
                //declined
                gameCenter.cancelChallenge(request.session());
                vm = declinedChallenge(vm);
              }else{
                vm = youHaveBeenChallenged(vm, request.session());
              }
            }//end of if userDecision != null
            else{
              if(gameCenter.isChallengeAccepted(request.session()) == true){
                vm = loadGame(vm);
              }else{
                vm = youHaveBeenChallenged(vm, request.session());
              }

            }
          }else{
            //check on status
            if(gameCenter.isChallengeAccepted(request.session())){
              //accepted, start
              vm = loadGame(vm);
            }else{
              //no response yet, pending

              //check if challenger cancelled request
              final String userWithdraw = request.queryParams(USER_WITHDRAW);
              if(userWithdraw != null && userWithdraw.length()>0){
                //withdraw request
                gameCenter.cancelChallenge(request.session());
                vm = declinedChallenge(vm);
              }else{
                vm = waitingForOpponent(vm);
              }

            }
          }
        }else{
          //no active challenge
          //check if posted a request for a challenge
          final String opponentName = request.queryParams(NEW_CHALLENGE);
          if(opponentName != null && opponentName.length()>0){
            //player asked to challenge a player
            gameCenter.challengePlayer(request.session(),opponentName);
            vm = waitingForOpponent(vm);
          }
        }

       //check if player is challenging another
       return new ModelAndView(vm, VIEW_NAME);
    }
    else {
      //not logged in
      return new ModelAndView(vm , GetSignInRoute.VIEW_NAME);
    }

  }

  public Map<String, Object> loadGame(final Map<String, Object> vm){
    vm.put(CHALLENGE_MSG, "Game is loading...");
    return vm;
  }

  public Map<String, Object> waitingForOpponent(final Map<String, Object> vm){
    vm.put(CHALLENGE_MSG, "Waiting for opponent...");
    vm.put(IS_CHALLENGED_ATTR, 0);
    return vm;
  }

  public Map<String, Object> declinedChallenge(final Map<String, Object> vm){
    vm.put(CHALLENGE_MSG, "Cancelling challenge...");
    return vm;
  }


  public Map<String, Object> youHaveBeenChallenged(final Map<String, Object> vm, final Session session){
    vm.put(CHALLENGE_MSG, "You have been challenged by " + gameCenter.getChallengerName(session));
    vm.put(IS_CHALLENGED_ATTR, 1);
    return vm;
  }

}