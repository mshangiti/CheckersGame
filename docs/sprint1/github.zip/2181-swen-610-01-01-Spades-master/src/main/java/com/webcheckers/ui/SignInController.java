package com.webcheckers.ui;

import com.webcheckers.appl.GameCenter;
import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.TemplateViewRoute;

import java.util.HashMap;
import java.util.Map;

public class SignInController implements TemplateViewRoute {
    //
    // Constants
    //
    static final String VIEW_NAME = "signin.ftl";
    static final String TITLE = "Welcome";

    @Override
    public ModelAndView handle(Request request, Response response) {
        Map<String, Object> vm = new HashMap<>();
        vm.put("title",SignInController.TITLE);
        if(GameCenter.checkIfLoggedIn(request.session())) {
            //user loggedin
            //redirect to lobby
            vm.put(GameCenter.SESSION_USER, GameCenter.getUserName(request.session()));
            return new ModelAndView(vm, HomeController.VIEW_NAME);
        }
        else{
            //not loggedin
            return new ModelAndView(vm , VIEW_NAME);
        }

    }
}
