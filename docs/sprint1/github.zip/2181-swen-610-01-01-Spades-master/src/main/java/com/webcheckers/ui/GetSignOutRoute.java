package com.webcheckers.ui;

import com.webcheckers.appl.GameCenter;
import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.TemplateViewRoute;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

public class GetSignOutRoute implements TemplateViewRoute {

    //
    // constants
    //

    static final String TITLE = "Welcome";


    //
    // TemplateViewRoute method
    //

    /**
     * {@inheritDoc}
     */
    @Override
    public ModelAndView handle(Request request, Response response) {
        // start building the View-Model
        final Map<String, Object> vm = new HashMap<>();
        vm.put("title", GetSignOutRoute.TITLE);

        //signout user
        GameCenter.removeUser(request.session());

        //redirect to signin page
        return new ModelAndView(vm, SignInController.VIEW_NAME);
    }
}
