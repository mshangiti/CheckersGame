package com.webcheckers.ui;

import java.util.HashMap;
import java.util.Map;

import com.webcheckers.appl.GameCenter;
import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.TemplateViewRoute;

/**
 * The Web Controller for the Home page.
 *
 *
 */
public class HomeController implements TemplateViewRoute {

  //
  // Constants
  //
  static final String VIEW_NAME = "home.ftl";
  static final String TITLE = "Welcome";

  @Override
  public ModelAndView handle(Request request, Response response) {
    Map<String, Object> vm = new HashMap<>();
    vm.put("title", HomeController.TITLE);
    if(GameCenter.checkIfLoggedIn(request.session())) {
      //user loggedin
      vm.put(GameCenter.SESSION_USER, GameCenter.getUserName(request.session()));
      return new ModelAndView(vm, VIEW_NAME);
    }
    else{
      //not loggedin
      return new ModelAndView(vm , SignInController.VIEW_NAME);
    }

  }

}