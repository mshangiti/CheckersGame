package com.webcheckers.appl;
import java.util.ArrayList;
import java.util.Objects;
import java.util.logging.Logger;
import spark.Session;
import com.webcheckers.model.User;


/**
 * The object to coordinate the state of the Web Application.
 */

public class GameCenter {

    //globals
    public static final String SESSION_USER = "username";


    //list of online/active users
    private  static  ArrayList<User> activeUsers = new ArrayList<>();

    /**
     * Adding a new user (at sign-in)
     *
     * @param user, Session
     *    The user to add
     *    The current session
     */

    public synchronized static void addUser(User user, final Session session){
        //add user to activeUsers
        activeUsers.add(user);

        //add to session
        session.attribute(SESSION_USER, user);
    }

    /**
     * Removing a new user (at sign-out)
     *
     * @param session
     *    The user to remove
     */
    public synchronized static void removeUser(final Session session){

        //get user
        User user = session.attribute(SESSION_USER);

        //add user to activeUsers
        activeUsers.remove(user);

        //remove from session
        session.removeAttribute(SESSION_USER);
    }


    /**
     * Check if username is in use
     *
     * @param username
     *    The username to check
     */
    public static boolean checkUsername(String username){
        for (User temp:activeUsers){
            if(temp.getName().equalsIgnoreCase(username)){
                return false;
            }
        }
        return true;
    }

    /**
     * get the username from the session
     *
     * @param session
     *    The user's session
     */
    public static String getUserName(Session session){
        User myuser = session.attribute(SESSION_USER);
        return myuser.getName();
    }


    /**
     * Check if user is loggedin
     *
     * @param session
     *    The user's session
     */
    public static boolean checkIfLoggedIn(Session session){
        User myuser = session.attribute(SESSION_USER);
        if(myuser != null){
            return true;
        }else{
            return false;
        }
    }
}
