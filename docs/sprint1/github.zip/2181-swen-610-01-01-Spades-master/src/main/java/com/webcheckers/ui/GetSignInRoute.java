package com.webcheckers.ui;

import com.webcheckers.appl.GameCenter;
import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.TemplateViewRoute;
import java.util.HashMap;
import java.util.Map;

/**
 * The {@code GET /singin} route handler.
 */

public class GetSignInRoute implements TemplateViewRoute {

    //
    // constants
    //

    static final String TITLE = "Welcome";

    //
    // TemplateViewRoute method
    //

    /**
     * {@inheritDoc}
     */
    @Override
    public ModelAndView handle(Request request, Response response) {
        // start building the View-Model
        final Map<String, Object> vm = new HashMap<>();
        vm.put("title", GetSignInRoute.TITLE);

        if(GameCenter.checkIfLoggedIn(request.session())){
            //user loggedin
            vm.put(GameCenter.SESSION_USER, GameCenter.getUserName(request.session()));
            return new ModelAndView(vm, HomeController.VIEW_NAME);
        }else {
            //new user
            //redirect to signin page
            return new ModelAndView(vm, SignInController.VIEW_NAME);
        }
    }

}
