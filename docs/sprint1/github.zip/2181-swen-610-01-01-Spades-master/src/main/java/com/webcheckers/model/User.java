package com.webcheckers.model;


/*
 * This class represents a User playing a game
 */
public class User {

    private String name;

    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
}
