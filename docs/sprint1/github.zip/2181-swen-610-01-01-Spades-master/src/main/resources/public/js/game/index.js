/**
 * This file is used by the Game view HTML code to use RequireJS
 * to load the JS code used by the view.
 */
requirejs(["main"]);